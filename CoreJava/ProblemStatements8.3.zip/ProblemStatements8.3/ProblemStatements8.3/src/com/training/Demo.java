package com.training;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

class ThreadA extends Thread{
    public void run( ) {
    	FileInputStream in=null;
        String text = null;
   
        try{
          Thread.sleep(500);
          File inputFile = new File("D:/testing/first.txt");
          Scanner sc= new Scanner(inputFile);
          while(sc.hasNextLine()) {
             int a=sc.nextInt();
             System.out.println(a);

          }
       } catch(Exception ex) {
       }  
      }
}

class ThreadB extends Thread {
   public void run() {
	   FileInputStream in=null;
     
       try{
         Thread.sleep(500);
         File inputFile = new File("D:/testing/first.txt");
         Scanner sc= new Scanner(inputFile);
         
       while(sc.hasNextLine()) {
    	  int b= sc.nextInt();   
	      int fact1=1;
          for(int i = 1; i <= b; i++)
          {
             fact1 = fact1 * i;
          }
       System.out.println("Factorial of "+b+" is: "+fact1);
       }
       } catch(Exception ex) {
       }  
}
}
public class Demo {
   public static void main(String args[]) {
        ThreadA a = new ThreadA();
        ThreadB b = new ThreadB();
        
        b.start();
   }
}



