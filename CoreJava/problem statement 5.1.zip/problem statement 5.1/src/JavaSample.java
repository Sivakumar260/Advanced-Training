public class JavaSample {
	public static void main(String[] args) {
		
	
	String txt= "JAVA is Simple";
	
	System.out.println(txt.toUpperCase()); 
	
	System.out.println(txt.toLowerCase()); 
	
	
	String[] words=txt.split("\\s");	
	for(String w:words){  
		System.out.print(w.charAt(0)); 
		System.out.print(" ");
	}
	System.out.println(" ");
	String[] words1=txt.split("\\s");	
	String output="";
	for(int i = words1.length; i > 0 ; i--) {
		output =output+words[i-1]+" ";
		}
		System.out.println(output);

	//String Builder reverse
	StringBuilder words2= new StringBuilder(output);
	StringBuilder reverseStr = words2.reverse();
	System.out.println("Reverse String = " + reverseStr.toString());
	int a = 0;
	for(int i=0;i<txt.length();++i)
	  {
	   if(txt.charAt(i)!=' ')
	    a++;
	  }
	System.out.println("length of string " + a);
}
}