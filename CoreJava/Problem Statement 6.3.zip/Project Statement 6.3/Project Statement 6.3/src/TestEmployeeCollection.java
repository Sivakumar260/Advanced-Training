import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;


public class TestEmployeeCollection {
public static void main(String[] args) {
	LinkedList<Employee> v = addInput();
	display(v);
}

private static LinkedList<Employee> addInput() {
	// TODO Auto-generated method stub
	Employee e1 = new Employee(101,"siva","APK") ;
	Employee e2 = new Employee(102,"rishi","MDU") ;
	Employee e3 = new Employee(103,"Vicky","CBE") ;
	LinkedList<Employee> v = new LinkedList<Employee>();
	v .add(e1);
	v.add(e2);
	v.add(e3);
	return v;
}

private static void display(LinkedList<Employee> v) {
	ListIterator<Employee> i = v.listIterator(v.size());

	while (i.hasPrevious()) {
		System.out.println(((Employee) i).getEmpid()+"\t"+((Employee) i).getEname()+"\t"+((Employee) i).getAddress());
	}
}
}
