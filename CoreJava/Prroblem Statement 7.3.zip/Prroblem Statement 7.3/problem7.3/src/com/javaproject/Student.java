package com.javaproject;

public class Student
{
     int roll,age;
     String name,Address;
     Student()
     {
          roll=0;
          name=null;
          age=0;
          Address=null;
     }
     Student(int r,String n,int a,String b) throws Exception
     {
          roll=r;
          Address=b;
          int l,temp=0;
          l = n.length();
          for(int i=0;i<l;i++)
          {
               char ch;
               ch=n.charAt(i);
               if(ch<'A' || ch>'Z' && ch<'a' || ch>'z')
                    temp=1;
          }
         
          try
          {
               if(temp==1)
                    throw new Exception();
               else
                    name=n;
          }
          finally {
        	  
          }
          try
          {
               if(a>0)
                    age=a;
               else
                    throw new Exception();
          }
          finally {
        	  
          }
     }
     void display()
     {
          System.out.println("roll Name Age Address");
          System.out.println("---------------------");
          System.out.println(roll+" "+name+" "+age+" " +Address);
     }
}